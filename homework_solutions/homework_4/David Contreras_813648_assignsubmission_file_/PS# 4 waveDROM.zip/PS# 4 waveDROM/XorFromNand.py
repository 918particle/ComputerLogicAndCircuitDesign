import wavedrom

signals = """
{
  "assign": [
    ["out",
      ["~&", ["~&", "a", ["~", "b"]], ["~&", ["~", "a"], "b"]]
    ]
  ]
}
"""
svg_xor_gate = wavedrom.render(signals)
svg_xor_gate.saveas("xor_gate_diagram.svg")
