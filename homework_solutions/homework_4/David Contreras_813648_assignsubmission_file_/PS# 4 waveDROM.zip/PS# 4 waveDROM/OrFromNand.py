import wavedrom

signals = """
{
  "assign": [
    ["out",
      ["~&", ["~", ["~&", "a"], ["~&", "b"]]]
    ]
  ]
}
"""

svg_or_gate = wavedrom.render(signals)
svg_or_gate.saveas("or_gate_diagram.svg")