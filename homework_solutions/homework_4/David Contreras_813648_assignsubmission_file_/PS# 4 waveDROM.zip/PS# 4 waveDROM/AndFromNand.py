import wavedrom

signals = """
{
  "assign": [
    ["out",
    ["~&", ["~", ["~&", "a", "b"]]]
    ]
  ]
}
"""
svg_and_gate = wavedrom.render(signals)
svg_and_gate.saveas("and_gate_diagram.svg")
